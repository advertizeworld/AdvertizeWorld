import { motion } from 'motion/react';
import { X, ArrowLeft } from 'lucide-react';
import { Logo } from './Logo';

interface LegalPageProps {
  type: 'privacy' | 'terms';
  onClose: () => void;
}

export const LegalPage = ({ type, onClose }: LegalPageProps) => {
  const content = {
    privacy: {
      title: 'Privacy Policy',
      sections: [
        {
          id: '1',
          title: '1. Introduction',
          content: 'Advertize.World ("we," "us," or "our") respects your privacy and is committed to protecting your personal information in accordance with applicable U.S. data protection laws.'
        },
        {
          id: '2',
          title: '2. Information We Collect',
          subsections: [
            {
              title: '2.1 Information You Provide',
              items: [
                'Name, email, phone number',
                'Business information',
                'Project requirements and materials'
              ]
            },
            {
              title: '2.2 Automatically Collected Information',
              items: [
                'IP address',
                'Browser type',
                'Device information',
                'Usage data'
              ]
            },
            {
              title: '2.3 Third-Party Sources',
              content: 'We may receive data from analytics providers or marketing platforms.'
            }
          ]
        },
        {
          id: '3',
          title: '3. How We Use Information',
          content: 'We use your information to:',
          items: [
            'Provide and improve our Services;',
            'Communicate with you;',
            'Process payments;',
            'Analyze usage patterns to enhance user experience;',
            'Ensure security and prevent fraud.'
          ]
        },
        {
          id: '4',
          title: '4. Information Sharing',
          content: 'We do not sell your personal information. We may share data with trusted service providers who assist us in operating our business, so long as those parties agree to keep this information confidential.'
        },
        {
          id: '5',
          title: '5. Data Security',
          content: 'We implement a variety of security measures to maintain the safety of your personal information. However, no method of transmission over the Internet is 100% secure.'
        },
        {
          id: '6',
          title: '6. Your Rights',
          content: 'Depending on your location, you may have rights regarding your personal data, including the right to access, correct, or delete your information. Please contact us to exercise these rights.'
        },
        {
          id: '7',
          title: '7. Contact Us',
          content: 'If you have any questions regarding this Privacy Policy, you may contact us at advertize.w@gmail.com.'
        }
      ]
    },
    terms: {
      title: 'Terms of Service',
      sections: [
        {
          id: '1',
          title: '1. Acceptance of Terms',
          content: 'These Terms of Service ("Terms") constitute a legally binding agreement between you ("Client," "you," or "your") and Advertize.World ("Company," "we," "us," or "our"). By accessing, engaging, or using our services, including but not limited to AI UGC Ads, AI Design, and AI Copywriting (collectively, the "Services"), you acknowledge that you have read, understood, and agree to be bound by these Terms. If you do not agree, you must not use our Services.'
        },
        {
          id: '2',
          title: '2. Description of Services',
          content: 'Advertize.World provides AI-assisted marketing and creative services, including:',
          items: [
            'AI-generated User-Generated Content advertisements ("AI UGC Ads")',
            'AI-assisted visual and graphic design ("AI Design")',
            'AI-assisted copywriting and content generation ("AI Copywriting")'
          ],
          footer: 'All deliverables are produced using a combination of artificial intelligence tools and human oversight.'
        },
        {
          id: '3',
          title: '3. Eligibility',
          content: 'You represent and warrant that:',
          items: [
            'You are at least 18 years old;',
            'You have the legal authority to enter into this agreement;',
            'Your use of the Services complies with all applicable laws and regulations.'
          ]
        },
        {
          id: '4',
          title: '4. Client Responsibilities',
          content: 'You agree to:',
          items: [
            'Provide accurate, complete, and lawful instructions and materials;',
            'Maintain the confidentiality of any account credentials;',
            'Use the Services only for lawful purposes.'
          ]
        },
        {
          id: '5',
          title: '5. Intellectual Property',
          content: 'Unless otherwise agreed in writing, Advertize.World retains all rights to the underlying AI models and methodologies. Clients are granted a license to use the final deliverables for their intended business purposes upon full payment.'
        },
        {
          id: '6',
          title: '6. Payment Terms',
          content: 'Fees for Services are outlined in individual project proposals or service agreements. Payments are due according to the schedule specified therein. Late payments may result in suspension of Services.'
        },
        {
          id: '7',
          title: '7. Limitation of Liability',
          content: 'To the maximum extent permitted by law, Advertize.World shall not be liable for any indirect, incidental, or consequential damages arising out of the use or inability to use our Services.'
        },
        {
          id: '8',
          title: '8. Governing Law',
          content: 'These Terms shall be governed by and construed in accordance with the laws of the jurisdiction in which the Company is registered, without regard to its conflict of law provisions.'
        },
        {
          id: '9',
          title: '9. Contact Information',
          content: 'Questions about the Terms of Service should be sent to us at advertize.w@gmail.com.'
        }
      ]
    }
  };

  const activeContent = content[type];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-[100] bg-pearl flex flex-col"
    >
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-6 py-24">
          <button 
            onClick={onClose}
            className="flex items-center gap-2 text-dark-blue/60 hover:text-dark-blue transition-colors mb-12 group"
          >
            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
            <span className="text-[10px] uppercase tracking-[0.2em] font-semibold">Back to Home</span>
          </button>

          <div className="flex items-center gap-4 mb-16">
            <Logo className="w-10 h-10" />
            <div>
              <h1 className="text-3xl md:text-5xl font-serif text-dark-blue">{activeContent.title}</h1>
              <p className="text-[10px] uppercase tracking-[0.4em] text-logo-gold mt-2 font-semibold">Advertize.World</p>
            </div>
          </div>

          <div className="space-y-12">
            {activeContent.sections.map((section) => (
              <div key={section.id} className="space-y-6">
                <h2 className="text-xl font-bold text-dark-blue border-b border-dark-blue/10 pb-4">{section.title}</h2>
                
                {section.content && (
                  <p className="text-neutral-600 leading-relaxed font-light">
                    {section.content}
                  </p>
                )}

                {section.subsections && (
                  <div className="space-y-8 pl-4">
                    {section.subsections.map((sub, idx) => (
                      <div key={idx} className="space-y-4">
                        <h3 className="text-lg font-semibold text-dark-blue/80">{sub.title}</h3>
                        {sub.content && <p className="text-neutral-600 leading-relaxed font-light">{sub.content}</p>}
                        {sub.items && (
                          <ul className="list-disc list-inside space-y-2 text-neutral-600 font-light pl-2">
                            {sub.items.map((item, i) => (
                              <li key={i}>{item}</li>
                            ))}
                          </ul>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {section.items && (
                  <ul className="list-disc list-inside space-y-3 text-neutral-600 font-light pl-4">
                    {section.items.map((item, i) => (
                      <li key={i}>{item}</li>
                    ))}
                  </ul>
                )}

                {section.footer && (
                  <p className="text-neutral-600 leading-relaxed font-light italic pt-4">
                    {section.footer}
                  </p>
                )}
              </div>
            ))}
          </div>

          <div className="mt-24 pt-12 border-t border-dark-blue/10 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <Logo className="w-6 h-6 opacity-50" />
              <span className="text-[10px] uppercase tracking-[0.2em] text-neutral-400">© {new Date().getFullYear()} Advertize.World</span>
            </div>
            <button 
              onClick={onClose}
              className="btn-premium"
            >
              Accept & Close
            </button>
          </div>
        </div>
      </div>

      <button 
        onClick={onClose}
        className="fixed top-8 right-8 p-3 bg-white/90 backdrop-blur-md border border-dark-blue/10 rounded-full text-dark-blue hover:bg-dark-blue hover:text-pearl transition-all duration-300 z-[200] shadow-lg"
        aria-label="Close"
      >
        <X size={24} />
      </button>
    </motion.div>
  );
};
