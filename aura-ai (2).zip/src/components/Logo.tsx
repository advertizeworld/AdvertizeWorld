import React from 'react';

export const Logo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg 
      viewBox="0 0 400 300" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg" 
      className={className}
    >
      {/* Globe Grid */}
      <circle cx="200" cy="140" r="80" stroke="#E5E7EB" strokeWidth="1" />
      <ellipse cx="200" cy="140" rx="30" ry="80" stroke="#E5E7EB" strokeWidth="1" />
      <ellipse cx="200" cy="140" rx="60" ry="80" stroke="#E5E7EB" strokeWidth="1" />
      <line x1="120" y1="140" x2="280" y2="140" stroke="#E5E7EB" strokeWidth="1" />
      <path d="M135 100 Q200 110 265 100" stroke="#E5E7EB" strokeWidth="1" fill="none" />
      <path d="M135 180 Q200 170 265 180" stroke="#E5E7EB" strokeWidth="1" fill="none" />

      {/* Swooshes */}
      <path 
        d="M150 100 Q130 180 280 220" 
        stroke="#000C1D" 
        strokeWidth="12" 
        strokeLinecap="round" 
        fill="none" 
      />
      <path 
        d="M160 210 Q250 210 310 140" 
        stroke="#A37E2C" 
        strokeWidth="10" 
        strokeLinecap="round" 
        fill="none" 
      />
      
      {/* Arrow Head */}
      <path d="M300 130 L320 120 L325 150 Z" fill="#A37E2C" />

      {/* Stars */}
      <path d="M260 100 L263 105 L268 106 L264 110 L265 115 L260 112 L255 115 L256 110 L252 106 L257 105 Z" fill="#000C1D" />
      <path d="M280 115 L282 118 L285 119 L282 121 L283 124 L280 122 L277 124 L278 121 L275 119 L278 118 Z" fill="#000C1D" />

      {/* Text */}
      <text 
        x="200" 
        y="165" 
        textAnchor="middle" 
        fill="#000C1D" 
        style={{ font: 'bold 56px sans-serif' }}
      >
        Advertize
      </text>
      <text 
        x="200" 
        y="205" 
        textAnchor="middle" 
        fill="#A37E2C" 
        style={{ font: 'bold 24px sans-serif', letterSpacing: '8px' }}
      >
        WORLD
      </text>
    </svg>
  );
};
