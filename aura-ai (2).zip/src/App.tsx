/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform, useMotionValueEvent } from 'motion/react';
import { Menu, X, ArrowRight, Globe, Zap, Users, BarChart3, Instagram, Mail, Target, Cpu, Layout, Maximize, Eye, Search, PenTool, RefreshCw, Rocket, ChevronDown, Phone } from 'lucide-react';
import { Logo } from './components/Logo';
import { LegalPage } from './components/LegalPage';
import { AnimatePresence } from 'motion/react';

const ParticleCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let particles: Particle[] = [];
    let animationFrameId: number;

    class Particle {
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;

      constructor() {
        this.x = Math.random() * canvas!.width;
        this.y = Math.random() * canvas!.height;
        this.size = 1.5;
        this.speedX = Math.random() * 0.2 - 0.1;
        this.speedY = Math.random() * 0.2 - 0.1;
      }

      draw() {
        if (!ctx) return;
        ctx.fillStyle = '#C5A021';
        ctx.globalAlpha = 0.15;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    const draw = () => {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (let i = 0; i < particles.length; i++) {
        particles[i].draw();

        for (let j = i; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < 150) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(197, 160, 33, ${0.08 - distance / 1800})`;
            ctx.lineWidth = 0.3;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
            ctx.closePath();
          }
        }
      }
    };

    const init = () => {
      particles = [];
      for (let i = 0; i < 60; i++) {
        particles.push(new Particle());
      }
      draw();
    };

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      init();
    };

    window.addEventListener('resize', resize);
    resize();

    return () => {
      window.removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 w-full h-full pointer-events-none z-0" />;
};

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showProcess, setShowProcess] = useState(false);
  const [isHeaderDark, setIsHeaderDark] = useState(false);
  const [legalPage, setLegalPage] = useState<'privacy' | 'terms' | null>(null);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formError, setFormError] = useState('');

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    setFormError('');

    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      setFormStatus('error');
      setFormError('All fields are required.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setFormStatus('error');
      setFormError('Please enter a valid email address.');
      return;
    }

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setFormStatus('success');
        setFormData({ name: '', email: '', message: '' });
      } else {
        const data = await response.json();
        setFormStatus('error');
        setFormError(data.error || 'Failed to send message.');
      }
    } catch (error) {
      setFormStatus('error');
      setFormError('An unexpected error occurred. Please try again.');
    }
  };

  const { scrollY, scrollYProgress } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    const whyUsSection = document.getElementById('why-us');
    const footer = document.querySelector('footer');
    
    let isDark = false;
    
    if (whyUsSection) {
      const rect = whyUsSection.getBoundingClientRect();
      // If the header (around 60px height) is within the section
      if (rect.top <= 60 && rect.bottom >= 60) {
        isDark = true;
      }
    }
    
    if (footer) {
      const rect = footer.getBoundingClientRect();
      if (rect.top <= 60) {
        isDark = true;
      }
    }
    
    setIsHeaderDark(isDark);
  });

  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);

  const navItems = [
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Portfolio', href: '#layers' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <div className="min-h-screen selection:bg-dark-blue selection:text-pearl overflow-x-hidden">
      <ParticleCanvas />

      {/* Navigation */}
      <nav className={`fixed w-full z-50 px-6 md:px-12 py-6 flex justify-between items-center transition-colors duration-500 ${isMenuOpen ? 'text-midnight-navy' : (isHeaderDark ? 'text-pearl' : 'text-midnight-navy')}`}>
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-2"
        >
          <Logo className={`w-12 h-12 transition-all duration-500 ${isMenuOpen ? '' : (isHeaderDark ? 'brightness-0 invert' : '')}`} />
          <div className={`text-xl tracking-tighter font-bold transition-colors duration-500 ${isMenuOpen ? 'text-midnight-navy' : (isHeaderDark ? 'text-pearl' : 'text-midnight-navy')}`}>
            <span>ADVERTIZE</span>
            <span className="gold-metal-text">.WORLD</span>
          </div>
        </motion.div>
        
        <div className="hidden md:flex items-center space-x-10 text-[10px] uppercase tracking-[0.2em]">
          {navItems.map((item, i) => (
            <motion.a
              key={item.name}
              href={item.href}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className={item.name === 'Contact' 
                ? `border px-6 py-2 transition-all duration-500 ${isHeaderDark ? 'border-white text-white hover:bg-white hover:text-dark-blue' : 'border-dark-blue text-dark-blue hover:bg-dark-blue hover:text-pearl'}` 
                : "hover:opacity-50 transition-opacity"}
            >
              {item.name}
            </motion.a>
          ))}
        </div>

        <button className={`md:hidden transition-colors duration-500 ${isMenuOpen ? 'text-dark-blue' : (isHeaderDark ? 'text-pearl' : 'text-dark-blue')}`} onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </nav>

      {/* Mobile Menu */}
      <motion.div
        initial={false}
        animate={isMenuOpen ? { opacity: 1, x: 0 } : { opacity: 0, x: '100%' }}
        className="fixed inset-0 z-40 bg-pearl flex flex-col items-center justify-center space-y-8 md:hidden"
      >
        {navItems.map((item) => (
          <a
            key={item.name}
            href={item.href}
            onClick={() => setIsMenuOpen(false)}
            className="text-3xl font-serif italic"
          >
            {item.name}
          </a>
        ))}
      </motion.div>

      {/* Content Container */}
      <main className="relative z-10">
        
        {/* Hero Section */}
        <header className="h-screen flex flex-col justify-center items-center text-center px-6">
          <motion.div style={{ opacity }}>
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
              className="text-3xl md:text-7xl mb-8 max-w-5xl font-serif leading-tight text-midnight-navy"
            >
              Bringing Vision to Life. <br />
              <span className="italic gold-metal-text">Precision in every execution.</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="text-lg md:text-xl text-neutral-500 mb-12 max-w-xl mx-auto font-light"
            >
              Modern solutions crafted through AI and strategic thinking.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="flex flex-col md:flex-row gap-6"
            >
              <a href="#services" className="btn-premium inline-flex items-center gap-3">
                View Services
                <ArrowRight size={14} />
              </a>
              <a href="#contact" className="btn-premium bg-dark-blue text-pearl hover:bg-accent-blue inline-flex items-center gap-3">
                Start a Conversation
              </a>
            </motion.div>
          </motion.div>
        </header>

        {/* Trust Section */}
        <section className="max-w-6xl mx-auto py-20 px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { icon: Users, label: '40+ Clients Served' },
              { icon: Zap, label: '100+ Projects Delivered' },
              { icon: BarChart3, label: 'AI-Driven Workflow' },
              { icon: Globe, label: 'Global Reach' }
            ].map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="flex flex-col items-center space-y-4"
              >
                <item.icon size={27} className="text-accent-blue opacity-50" />
                <span className="text-[11px] uppercase tracking-[0.2em] text-neutral-500">{item.label}</span>
              </motion.div>
            ))}
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="max-w-5xl mx-auto py-40 px-6 text-center">
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-xl md:text-4xl text-midnight-navy leading-relaxed font-serif italic font-light"
          >
            "Advertize.World operates where creativity meets technology. 
            We create, design, and market ads that don’t just look good but drive engagement, 
            conversions, and real business growth"
          </motion.p>
        </section>

        {/* Services Section */}
        <section id="services" className="max-w-6xl mx-auto py-32 px-6">
          <h2 className="text-4xl md:text-6xl mb-24 font-serif text-center">Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            {[
              { 
                title: 'AI UGC Ads', 
                desc: 'AI-enhanced user-generated style ads crafted to deliver authentic engagement and scalable performance. Includes high-converting UGC-style video ads designed for both digital and large-scale broadcast environments, AI-generated spokesperson content, strategically developed hooks and scripts, studio-quality voiceovers, retention-focused captioning, and multiple creative variations engineered for testing and scale.' 
              },
              { 
                title: 'Design', 
                desc: 'Refined, conversion-focused visuals built at the intersection of creative direction and AI precision. Includes high-performance website design (landing pages and funnels), premium social media creatives, scroll-stopping YouTube thumbnails, cohesive brand identity systems, and elevated e-commerce product visuals designed to strengthen brand presence and drive conversions across platforms.' 
              },
              { 
                title: 'Copywriting', 
                desc: 'Strategic, conversion-driven messaging developed to capture attention and influence decision-making at scale. Includes high-impact advertising copy, persuasive website and landing page content, conversion-optimized product descriptions, structured email campaigns, sales scripts, and compelling hooks and headlines tailored for measurable performance.' 
              },
              { 
                title: 'Marketing', 
                desc: 'Data-driven marketing systems designed to maximize reach, efficiency, and long-term growth. Includes full-scale campaign deployment across multi-channel ecosystems, advanced audience targeting, funnel architecture and optimization, continuous A/B testing, lead generation systems, intelligent retargeting strategies, and in-depth performance analytics to support scalable expansion.' 
              }
            ].map((service, i) => (
              <motion.div 
                key={service.title}
                initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="border-l border-accent-blue/20 pl-8 py-4"
              >
                <h3 className="text-2xl mb-4 font-serif">{service.title}</h3>
                <p className="text-neutral-500 font-light leading-relaxed">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Why Advertize.World Section */}
        <section id="why-us" className="bg-midnight-navy text-pearl py-40 px-6 overflow-hidden relative">
          <div className="absolute inset-0 marble-texture opacity-10 pointer-events-none" />
          <div className="max-w-6xl mx-auto relative z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-32"
            >
              <span className="text-[10px] uppercase tracking-[0.6em] text-antique-gold block mb-8 font-semibold">
                The Competitive Advantage
              </span>
              <h2 className="text-4xl md:text-7xl mb-12 font-serif">Why Choose Us</h2>
              <p className="max-w-3xl mx-auto text-neutral-400 font-light leading-relaxed text-xl">
                Advertize.World partners with growth-focused companies to deliver high-performance creative at scale — combining AI efficiency with strategic oversight to drive measurable business outcomes.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-32">
              {[
                { 
                  icon: <Target className="text-antique-gold" size={24} />,
                  title: 'Outcome-Driven Execution', 
                  desc: 'Every asset we produce is aligned with clear performance objectives — whether that’s customer acquisition, conversion optimization, or revenue growth. We prioritize impact over aesthetics.' 
                },
                { 
                  icon: <Cpu className="text-antique-gold" size={24} />,
                  title: 'Strategic Use of AI', 
                  desc: 'We leverage advanced AI systems as a force multiplier — not a replacement for strategy. Every output is guided, refined, and validated through human expertise to ensure commercial relevance.' 
                },
                { 
                  icon: <Layout className="text-antique-gold" size={24} />,
                  title: 'Platform-Native Creative', 
                  desc: 'We develop content specifically tailored to the dynamics of each platform — ensuring higher engagement, stronger retention, and improved conversion efficiency.' 
                },
                { 
                  icon: <Zap className="text-antique-gold" size={24} />,
                  title: 'Speed as a Competitive Advantage', 
                  desc: 'Our workflows are built for rapid deployment, enabling you to test, iterate, and scale campaigns significantly faster than traditional creative cycles.' 
                },
                { 
                  icon: <Maximize className="text-antique-gold" size={24} />,
                  title: 'Scalable Without Dilution', 
                  desc: 'From early-stage testing to high-volume campaign rollouts, we maintain strict brand consistency and messaging integrity across all outputs.' 
                },
                { 
                  icon: <Eye className="text-antique-gold" size={24} />,
                  title: 'Operational Transparency', 
                  desc: 'We operate as an extension of your team — with clear communication, defined processes, and full visibility into execution and performance.' 
                }
              ].map((item, i) => (
                <motion.div 
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="p-10 luxury-glass hover:bg-white/15 transition-all duration-500 group"
                >
                  <div className="mb-8 transform group-hover:scale-110 transition-transform duration-500">
                    {item.icon}
                  </div>
                  <h3 className="text-xl mb-4 font-serif text-pearl group-hover:text-antique-gold transition-colors">{item.title}</h3>
                  <p className="text-sm text-neutral-400 font-light leading-relaxed">
                    {item.desc}
                  </p>
                </motion.div>
              ))}
            </div>

            <div className="flex flex-col items-center">
              <button 
                onClick={() => setShowProcess(!showProcess)}
                className="bg-antique-gold text-midnight-navy px-10 py-4 transition-all duration-500 uppercase tracking-[0.2em] text-[0.7rem] hover:bg-pearl group flex items-center gap-3 font-bold shadow-xl"
              >
                Learn Our Process
                <motion.div
                  animate={{ rotate: showProcess ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronDown size={18} />
                </motion.div>
              </button>

              <motion.div
                initial={false}
                animate={{ height: showProcess ? 'auto' : 0, opacity: showProcess ? 1 : 0 }}
                className="overflow-hidden w-full"
              >
                <div className="pt-24 grid grid-cols-1 md:grid-cols-4 gap-8">
                  {[
                    { icon: <Search size={20} />, title: 'Understand', desc: 'Align with your goals and requirements.' },
                    { icon: <PenTool size={20} />, title: 'Create', desc: 'Produce high-quality outputs using AI and human guidance.' },
                    { icon: <RefreshCw size={20} />, title: 'Refine', desc: 'Iterate and improve based on feedback.' },
                    { icon: <Rocket size={20} />, title: 'Deliver & Scale', desc: 'Finalize assets and scale production as needed.' }
                  ].map((step, i) => (
                    <motion.div
                      key={step.title}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="text-center md:text-left"
                    >
                      <div className="flex items-center gap-4 mb-4 justify-center md:justify-start">
                        <div className="w-10 h-10 rounded-full bg-accent-blue/20 flex items-center justify-center text-accent-blue">
                          {step.icon}
                        </div>
                        <span className="text-accent-blue/40 font-mono text-sm">0{i + 1}</span>
                      </div>
                      <h4 className="text-lg font-semibold mb-2 uppercase tracking-wider">{step.title}</h4>
                      <p className="text-sm text-neutral-500 font-light">{step.desc}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="max-w-2xl mx-auto py-32 px-6">
          <h2 className="text-4xl md:text-6xl mb-20 font-serif text-center">Contact</h2>
          {formStatus === 'success' ? (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center p-12 luxury-glass border-antique-gold/20"
            >
              <p className="text-xl font-serif italic text-midnight-navy">Thank you! Your message has been sent successfully.</p>
              <button 
                onClick={() => setFormStatus('idle')}
                className="mt-8 btn-premium"
              >
                Send Another Message
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-10">
              <div className="border-b border-midnight-navy/20 focus-within:border-midnight-navy transition-colors pb-4">
                <input 
                  type="text" 
                  placeholder="NAME" 
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-transparent outline-none text-[12px] tracking-widest uppercase" 
                />
              </div>
              <div className="border-b border-midnight-navy/20 focus-within:border-midnight-navy transition-colors pb-4">
                <input 
                  type="email" 
                  placeholder="EMAIL" 
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-transparent outline-none text-[12px] tracking-widest uppercase" 
                />
              </div>
              <div className="border-b border-midnight-navy/20 focus-within:border-midnight-navy transition-colors pb-12">
                <textarea 
                  rows={4} 
                  placeholder="MESSAGE" 
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-transparent outline-none text-[12px] tracking-widest uppercase resize-none" 
                />
              </div>
              {formStatus === 'error' && (
                <p className="text-red-500 text-xs uppercase tracking-widest">{formError}</p>
              )}
              <button 
                type="submit" 
                disabled={formStatus === 'submitting'}
                className="btn-premium w-full disabled:opacity-50"
              >
                {formStatus === 'submitting' ? 'Sending...' : 'Start a Conversation'}
              </button>
            </form>
          )}
        </section>

        {/* Footer */}
        <footer className="bg-midnight-navy text-pearl py-24 px-6 border-t border-white/5 relative overflow-hidden">
          <div className="absolute inset-0 marble-texture opacity-5 pointer-events-none" />
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16 md:gap-8 relative z-10">
            {/* Brand Column */}
            <div className="col-span-1 md:col-span-1">
              <Logo className="w-12 h-12 mb-8" />
              <p className="text-neutral-400 text-sm leading-relaxed font-light max-w-[240px]">
                The world's first performance-engineered advertising agency. Combining institutional rigor with frontier technology.
              </p>
            </div>

            {/* Navigation Column */}
            <div>
              <h4 className="text-[10px] uppercase tracking-[0.4em] text-antique-gold mb-8 font-semibold">Navigation</h4>
              <ul className="space-y-4 text-sm text-neutral-400 font-light">
                <li><a href="#services" className="hover:text-antique-gold transition-colors">Services</a></li>
                <li><a href="#why-us" className="hover:text-antique-gold transition-colors">Expertise</a></li>
                <li><a href="#contact" className="hover:text-antique-gold transition-colors">Portfolio</a></li>
              </ul>
            </div>

            {/* Legal Column */}
            <div>
              <h4 className="text-[10px] uppercase tracking-[0.4em] text-antique-gold mb-8 font-semibold">Legal</h4>
              <ul className="space-y-4 text-sm text-neutral-400 font-light">
                <li><button onClick={() => setLegalPage('privacy')} className="hover:text-antique-gold transition-colors text-left">Privacy Policy</button></li>
                <li><button onClick={() => setLegalPage('terms')} className="hover:text-antique-gold transition-colors text-left">Terms of Service</button></li>
                <li><a href="#" className="hover:text-antique-gold transition-colors">Cookie Policy</a></li>
              </ul>
            </div>

            {/* Contact Column */}
            <div>
              <h4 className="text-[10px] uppercase tracking-[0.4em] text-antique-gold mb-8 font-semibold">Contact</h4>
              <ul className="space-y-4 text-sm text-neutral-400 font-light">
                <li className="flex items-center gap-3 group">
                  <Instagram size={16} className="text-antique-gold" />
                  <a 
                    href="https://www.instagram.com/advertize.world?igsh=cHR4a3F4YXFvYTJ6" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="hover:text-white transition-colors"
                  >
                    Instagram
                  </a>
                </li>
                <li className="flex items-center gap-3 group">
                  <Mail size={16} className="text-antique-gold" />
                  <a href="mailto:advertize.w@gmail.com" className="hover:text-white transition-colors">
                    advertize.w@gmail.com
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="max-w-6xl mx-auto mt-24 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 text-[10px] tracking-widest uppercase text-neutral-500">
            <p>© {new Date().getFullYear()} Advertize.World. All rights reserved.</p>
          </div>
        </footer>

        {/* Floating WhatsApp CTA */}
        <motion.a
          href="https://wa.me/447454768842"
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, scale: 0.5, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="fixed bottom-8 right-8 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl flex items-center justify-center group"
          aria-label="Chat on WhatsApp"
        >
          <svg 
            viewBox="0 0 24 24" 
            width="24" 
            height="24" 
            fill="currentColor"
          >
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
          </svg>
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-3 transition-all duration-500 ease-in-out whitespace-nowrap text-sm font-semibold">
            Chat with us
          </span>
        </motion.a>
      </main>

      <AnimatePresence>
        {legalPage && (
          <LegalPage 
            type={legalPage} 
            onClose={() => setLegalPage(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
